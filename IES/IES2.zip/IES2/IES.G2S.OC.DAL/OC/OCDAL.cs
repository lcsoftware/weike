﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

using IES.CC.OC.Model;
using Dapper;



namespace IES.G2S.OC.DAL.OC
{
     public class OCDAL
    {
        
    }
}

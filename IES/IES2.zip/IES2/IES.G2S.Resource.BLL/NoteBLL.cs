﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IES.G2S.Resource.BLL.Note
{
    /// <summary>
    /// 笔记
    /// </summary>
    public class NoteBLL
    {

    }
}

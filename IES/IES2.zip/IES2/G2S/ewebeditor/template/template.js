﻿// Best Preview Width, FileName, Description
config.Template = [
	["600", "01.htm", "01.htm"],
	["750", "02.htm", "02.htm"],
	["600", "03.htm", "03.htm"],
	["720", "04.htm", "04.htm"],
	["600", "05.htm", "05.htm"],
	["650", "06.htm", "06.htm"],
	["650", "article.htm", "文章模板"]
];
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace IES.AOP.G2S.DefaultConfigs
{
    /// <summary>
    /// exerciseaop.xml 对应的配置
    /// </summary>
    internal static class ExerciseServerConfig
    {
        //设置 UnityContainer 默认配置
        internal readonly static string DEFAULT_FilePath = "~/Configs/exerciseaop.config";
        internal readonly static string DEFAULT_Section = "unity";
        internal readonly static string DEFAULT_ContainerName = "FirstClass";

        static ExerciseServerConfig()
        {
            //初始化 默认配置
            if (ExerciseServerConfig.DEFAULT_FilePath != null)
                ExerciseServerConfig.DEFAULT_FilePath = HttpContext.Current.Server.MapPath(ExerciseServerConfig.DEFAULT_FilePath);
        }
    }
}

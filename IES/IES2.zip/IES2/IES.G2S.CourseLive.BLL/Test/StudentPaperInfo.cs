﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IES.G2S.CourseLive.BLL.Test
{
    /// <summary>
    /// 学生答卷信息
    /// </summary>
    public class StudentPaperInfo
    {

    }
}
